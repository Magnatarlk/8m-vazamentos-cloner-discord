export interface EmojiData {
    name: string;
    url?: string;
    base64?: string;
}
